#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main ()
{
	setlocale (LC_ALL, "Portuguese");
	printf ("Quest�o 02:\n\n");
	printf ("Quest�o 2.1:\n\n\n        A       \n       XOX      \n      XOXOX     \n     XXXXXXX    \n    XXXXXXXXX   \n   XXXXXXXXXXX   \n  XXXXXXXXXXXXX  \n XXXXXXXXXXXXXXX \n       XX       \n       XX      \n      XXXX    \n\n\n");
    printf ("Quest�o 2.2:\n\n\nXXXXX\nX   X\nX   X\nX   X\nXXXXX");
    return 0;
}
