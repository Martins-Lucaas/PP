#include <stdio.h>
#include <stdlib.h>
#include <locale.h>


int main ()
{
	setlocale (LC_ALL, "Portuguese");
	printf ("Quest�o 01:\n\n");
    printf ("O primeiro programa a gente nunca esquece!\n");
    return 0;
}
